# Software_engineering-0226-
SE lab programs 
#lab -1
1. Implement weather modeling* using the quadratic solution in stages: hard-coding variables
keyboard input, read from a file, for a single set of input, multiple sets of inputs.
